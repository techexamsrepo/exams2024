from car import Car

"""
    Create a SportsCar class by subclassing Car.
    Add the following properties:
        1. max_acceleration: float
        2. max_speed: int
"""