from enum import IntEnum


class CarType(IntEnum):
    HATCHBACK = 1
    SEDAN = 2
    COUPE = 3
    SUV = 4
    SPORTS = 5
